#pragma once
#include <iostream>
class Player
{
public:
	float m_Pos[2];
	Player()
	{
		m_Pos[0] = 30;
		m_Pos[1] = 30;
	}
};

